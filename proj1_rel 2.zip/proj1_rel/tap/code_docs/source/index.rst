.. TAP Controller documentation master file, created by
   sphinx-quickstart on Tue Jun  9 00:54:16 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to TAP Controller's documentation!
==========================================

Contents:

.. toctree::
   :maxdepth: 2

   modules

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

