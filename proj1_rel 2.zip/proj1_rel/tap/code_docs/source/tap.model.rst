model Package
=============

:mod:`tap_model` Module
-----------------------

.. automodule:: tap.model.tap_model
    :members:
    :undoc-members:
    :show-inheritance:

